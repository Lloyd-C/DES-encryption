// A DES encryption program


/**Rearranges the bits of a given list into an order decided by `Permutation`
 - Parameter toBePermutated: The list that will be permutated, or rearranged
 - Parameter permutation: A constant that decides the order of the rearrangement
 - Returns: A newly permutated list*/
func Permutate (toBePermutated: [Int], permutation: [Int], paraties: Bool) -> [Int] {
    
    var permutatedList = [Int](count: permutation.count, repeatedValue:0)
    
    for index in 0..<permutation.count {
        if paraties {
            let test = Int(permutation[index]/8)
            permutatedList[index] = toBePermutated[permutation[index]-test]
        } else {
            permutatedList[index] = toBePermutated[permutation[index]]
        }
    }
    return permutatedList
}

/**Splits up a list of numbers into a chosen number of sections
 - Parameter list: The array that is going to be split up
 - Parameter parseCount: The number of sections that `list` will be split up into
 - Returns: A new list that has been split up*/
func Parse (list: [Int], parseCount: Int) -> [[Int]] {
    var parsedList = [[Int]]()
    for i in 1...parseCount {
        parsedList.append(Array(list[(i-1)*list.count/parseCount ..< (i)*(list.count)/parseCount]))
    }
    return parsedList
}

/**A logical operation that outputs `true` only when the two inputs **differ** (one is true and the other is false)
 - Parameter binarySequence1: The first of the two operands used in the operation
 - Parameter binarySequence2: The second of the two operands used in the operation
 - Returns: A new binary sequences that is made as a result of the XOR operation*/
func XOR (binarySequence1: [Int], binarySequence2: [Int]) -> [Int] {
    var newBinarySequence = [Int]()
    for i in 0 ..< binarySequence1.count {
        if (binarySequence1[i] == 1 && binarySequence2[i] == 0) || (binarySequence1[i] == 0 && binarySequence2[i] == 1) {
            newBinarySequence.append(1)
        } else {
            newBinarySequence.append(0)
        }
    }
    return newBinarySequence
}

/// The initial permutation
let IP = [
    57, 49, 41, 33, 25, 17, 9,  1,
    59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5,
    63, 55, 47, 39, 31, 23, 15, 7,
    56, 48, 40, 32, 24, 16, 8,  0,
    58, 50, 42, 34, 26, 18, 10, 2,
    60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6]
/// The final permutation
let FP = [
    39,  7, 47, 15, 55, 23, 63, 31,
    38,  6, 46, 14, 54, 22, 62, 30,
    37,  5, 45, 13, 53, 21, 61, 29,
    36,  4, 44, 12, 52, 20, 60, 28,
    35,  3, 43, 11, 51, 19, 59, 27,
    34,  2, 42, 10, 50, 18, 58, 26,
    33,  1, 41,  9, 49, 17, 57, 25,
    32,  0, 40,  8, 48, 16, 56, 24]



/** The key used in the program

|K| = 56*/
var K = [Int](count: 56, repeatedValue: 0)

/**This is the plain text that will be encrypted

|M| = 64*/
let M = [Int](count: 64, repeatedValue: 0)

/** The Feistel Function (AKA F-function) operates on half a block (32 bits) at a time and consists of four stages:
 1. Expansion
 2. Key mixing
 3. Substitution
 4. Permutation
 - Parameter J: The 48-bit subkey for this round of the loop
 - Parameter R: The 32-bit input used for this round that was made from the output of the last round
 - Returns: A new value for R that becomes the input for the next round*/
func FeistelFunction (J: [Int], R: [Int]) -> [Int] {
    let expansionFunction = [
        31,  0,  1,  2,  3,  4,
         3,  4,  5,  6,  7,  8,
         7,  8,  9, 10, 11, 12,
        11, 12, 13, 14, 15, 16,
        15, 16, 17, 18, 19, 20,
        19, 20, 21, 22, 23, 24,
        23, 24, 25, 26, 27, 28,
        27, 28, 29, 30, 31,  0]
    let p = [
        15,  6, 19, 20, 28, 11, 27, 16,
         0, 14, 22, 25,  4, 17, 30,  9,
         1,  7, 23, 13, 31, 26,  2,  8,
        18, 12, 29,  5, 21, 10,  3, 24]
    let S = [
    // S1
    [14, 4, 13,  1,  2, 15, 11,  8,  3, 10,  6, 12,  5,  9,  0,  7,
     0, 15,  7,  4, 14,  2, 13,  1, 10,  6, 12, 11,  9,  5,  3,  8,
     4,  1, 14,  8, 13,  6,  2, 11, 15, 12,  9,  7,  3, 10,  5,  0,
    15, 12,  8,  2,  4,  9,  1,  7,  5, 11,  3, 14, 10,  0,  6, 13],
    
    // S2
    [15,  1,  8, 14,  6, 11,  3,  4,  9,  7,  2, 13, 12,  0,  5, 10,
      3, 13,  4,  7, 15,  2,  8, 14, 12,  0,  1, 10,  6,  9, 11,  5,
      0, 14,  7, 11, 10,  4, 13,  1,  5,  8, 12,  6,  9,  3,  2, 15,
     13,  8, 10,  1,  3, 15,  4,  2, 11,  6,  7, 12,  0,  5, 14,  9],
    
    // S3
    [10,  0,  9, 14,  6,  3, 15,  5,  1, 13, 12,  7, 11,  4,  2,  8,
     13,  7,  0,  9,  3,  4,  6, 10,  2,  8,  5, 14, 12, 11, 15,  1,
     13,  6,  4,  9,  8, 15,  3,  0, 11,  1,  2, 12,  5, 10, 14,  7,
      1, 10, 13,  0,  6,  9,  8,  7,  4, 15, 14,  3, 11,  5,  2, 12],
    
    // S4
    [ 7, 13, 14,  3,  0,  6,  9, 10,  1,  2,  8,  5, 11, 12,  4, 15,
     13,  8, 11,  5,  6, 15,  0,  3,  4,  7,  2, 12,  1, 10, 14,  9,
     10,  6,  9,  0, 12, 11,  7, 13, 15,  1,  3, 14,  5,  2,  8,  4,
      3, 15,  0,  6, 10,  1, 13,  8,  9,  4,  5, 11, 12,  7,  2, 14],
    
    // S5
    [2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
    14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
    4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
    11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3],
    
    // S6
    [12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
    10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
    9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
    4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13],
    
    // S7
    [4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
    13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
    1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
    6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12],
    
    // S8
    [13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
    1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
    7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
    2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11],
    ]
    let permutatedR = Permutate(R, permutation: expansionFunction, paraties: false)
    func StringToIndividualElements(string : Int) -> [Int] {
        var number = string
        var digits : [Int] = []
        while number > 0 {
            digits.insert(number % 2, atIndex: 0)
            number /= 2
        }
        return digits
    }
    let XORedR = XOR(permutatedR, binarySequence2: J)
    var parsedR = Parse(XORedR, parseCount: 8)
    var newR = [Int]()
    for i in 1...8 {
        let binaryString: String = String(parsedR[i-1][0]) + String(parsedR[i-1][1])
        let binaryDigits = Int(binaryString, radix: 2)!
        let finalString1 = String(parsedR[i-1][2]) + String(parsedR[i-1][3])
        let finalString2 = String(parsedR[i-1][4]) + String(parsedR[i-1][5])
        let finalString = finalString1 + finalString2
        let finalDigits = Int(finalString, radix: 2)!
        let number = S[i-1][16*binaryDigits + finalDigits]
        let fourDigitBinary = String(number, radix: 2)
        newR += StringToIndividualElements(Int(fourDigitBinary)!)
    }
    newR = Permutate(newR, permutation: p, paraties: false)
    return newR
}

/**Rotates it's input to the **left** by `j` positions
 - Parameter list: The array that is going to be shifted to the left
 - Parameter j: The number of positions that `list` will be shifted by
 - Returns: The new array made as a result of shifting `list`*/
func leftShift (list: [Int], j: Int) -> [Int] {
    var newList = [Int](count: list.count, repeatedValue: 0)
    for i in 0..<list.count {
        if i - j < 0 {
            newList[newList.count + (i - j)] = list[i]
        } else {
            newList[i - j] = list[i]
        }
    }
    return newList
}

/**The algorithm which generates the 16 subkeys
 - Parameter K: The 56-bit key decided by the two users
 - Returns: An array containing the 48-bit subkeys in the form of arrays*/
func KeySchedule (K: [Int]) -> [[Int]] {
    let PC1 = [56, 48, 40, 32, 24, 16,  8,
                0, 57, 49, 41, 33, 25, 17,
                9,  1, 58, 50, 42, 34, 26,
               18, 10,  2, 59, 51, 43, 35,
               62, 54, 46, 38, 30, 22, 14,
                6, 61, 53, 45, 37, 29, 21,
               13,  5, 60, 52, 44, 36, 28,
               20, 12,  4, 27, 19, 11,  3]
    let PC2 = [13, 16, 10, 23,  0,  4,
                2, 27, 14,  5, 20,  9,
               22, 18, 11,  3, 25,  7,
               15,  6, 26, 19, 12,  1,
               40, 51, 30, 36, 46, 54,
               29, 39, 50, 44, 32, 47,
               43, 48, 38, 55, 33, 52,
               45, 41, 49, 35, 28, 31]
    
    var subkeys = [[Int]]()
    let permutatedK = Permutate(K, permutation: PC1, paraties: true)
    var C = Parse(permutatedK, parseCount: 2)[0]
    var D = Parse(permutatedK, parseCount: 2)[1]
    var j: Int
    let set: Set<Int> = [1, 2, 9, 16]
    for r in 1...16 {
        if set.contains(r) {
            j = 1
        } else {
            j = 2
        }
        C = leftShift(C, j: j)
        D = leftShift(D, j: j)
        subkeys.append(Permutate(C+D, permutation: PC2, paraties: false))
    }
    return subkeys
}

let subkeys = KeySchedule(K)

let permutatedM = Permutate(M, permutation: IP, paraties: false) // Make a newly permutated M

var oldL = Parse(permutatedM, parseCount: 2)[0]
var oldR = Parse(permutatedM, parseCount: 2)[1]
var newL = [Int](); var newR = [Int]()
for r in 1...16 { // Generate the Feistal loop
    newL = oldR
    newR = XOR(oldL, binarySequence2: (FeistelFunction(subkeys[r-1], R: oldR)))
    oldL = newL
    oldR = newR
}

let C = Permutate(newL + newR, permutation: FP, paraties: false)
